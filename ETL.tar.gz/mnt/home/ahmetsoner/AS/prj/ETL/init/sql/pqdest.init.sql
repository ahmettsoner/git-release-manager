-- Create Table
CREATE TABLE cari_kart (
    cari_id SERIAL PRIMARY KEY,         -- Cari Kart ID (Primary Key)
    ad VARCHAR(100),                    -- Cari Adı
    soyad VARCHAR(100)                 -- Cari Soyadı
);
CREATE TABLE addresses (
    address_id SERIAL PRIMARY KEY,      -- Adres ID (Primary Key)
    cari_id INT REFERENCES cari_kart(cari_id),  -- Cari Kart ID (Foreign Key)
    address_type VARCHAR(50),           -- Adres Tipi (İş veya Ev)
    address TEXT                        -- Adres
);
CREATE TABLE phones (
    phone_id SERIAL PRIMARY KEY,        -- Telefon ID (Primary Key)
    cari_id INT REFERENCES cari_kart(cari_id),  -- Cari Kart ID (Foreign Key)
    phone_type VARCHAR(50),             -- Telefon Tipi (İş veya Ev)
    phone VARCHAR(15)                   -- Telefon Numarası
);


-- View Data
SELECT * FROM public.cari_kart Order By cari_id desc  Limit 1;

-- View Data
SELECT * FROM public.addresses Order By cari_id desc Limit 2;


-- View Data
SELECT * FROM public.phones Order By cari_id desc Limit 2;

-- Clear table
-- DELETE FROM cari_kart 

-- Clients Table
CREATE TABLE clients (
    client_id SERIAL PRIMARY KEY,
    full_name VARCHAR(100),
    email VARCHAR(255),
    phone VARCHAR(15),
    join_date TIMESTAMP
);

-- Purchases Table
CREATE TABLE purchases (
    purchase_id SERIAL PRIMARY KEY,
    client_id INT REFERENCES clients(client_id),
    product_name VARCHAR(100),
    quantity INT,
    price_per_product NUMERIC(10, 2),
    purchase_date TIMESTAMP
);
