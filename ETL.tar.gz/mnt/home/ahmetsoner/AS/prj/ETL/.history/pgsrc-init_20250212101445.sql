-- Logical Replication Açma
ALTER SYSTEM SET wal_level = logical;
SELECT pg_reload_conf();

-- Debezium Kullanıcısına Yetki Verme
CREATE USER debezium WITH REPLICATION LOGIN PASSWORD 'debezium123';
GRANT CONNECT ON DATABASE sourcedb TO debezium;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO debezium;

-- Kaynak Tablonun Oluşturulması
CREATE TABLE cari_kart (
    cari_id SERIAL PRIMARY KEY,
    ad VARCHAR(100),
    soyad VARCHAR(100),
    is_adres TEXT,
    ev_adres TEXT,
    is_telefon VARCHAR(15),
    ev_telefon VARCHAR(15)
);

-- Örnek Veri
INSERT INTO cari_kart (ad, soyad, is_adres, ev_adres, is_telefon, ev_telefon) 
VALUES ('Ahmet', 'Yılmaz', 'İş Adresi 123', 'Ev Adresi 456', '555-1111', '555-2222');
