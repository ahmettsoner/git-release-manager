-- Create Table
CREATE TABLE cari_kart (
    cari_id SERIAL PRIMARY KEY,         -- Cari Kart ID (Primary Key)
    ad VARCHAR(100),                    -- Cari Adı
    soyad VARCHAR(100)                 -- Cari Soyadı
);
CREATE TABLE addresses (
    address_id SERIAL PRIMARY KEY,      -- Adres ID (Primary Key)
    cari_id INT REFERENCES cari_kart(cari_id),  -- Cari Kart ID (Foreign Key)
    address_type VARCHAR(50),           -- Adres Tipi (İş veya Ev)
    address TEXT                        -- Adres
);
CREATE TABLE phones (
    phone_id SERIAL PRIMARY KEY,        -- Telefon ID (Primary Key)
    cari_id INT REFERENCES cari_kart(cari_id),  -- Cari Kart ID (Foreign Key)
    phone_type VARCHAR(50),             -- Telefon Tipi (İş veya Ev)
    phone VARCHAR(15)                   -- Telefon Numarası
);


-- View Data
SELECT * FROM public.cari_kart;

-- Clear table
-- DELETE FROM cari_kart 