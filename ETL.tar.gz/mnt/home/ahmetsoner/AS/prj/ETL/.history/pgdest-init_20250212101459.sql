CREATE TABLE cari_kart (
    cari_id SERIAL PRIMARY KEY,
    ad VARCHAR(100),
    soyad VARCHAR(100)
);

CREATE TABLE addresses (
    address_id SERIAL PRIMARY KEY,
    cari_id INT REFERENCES cari_kart(cari_id),
    address_type VARCHAR(50),
    address TEXT
);

CREATE TABLE phones (
    phone_id SERIAL PRIMARY KEY,
    cari_id INT REFERENCES cari_kart(cari_id),
    phone_type VARCHAR(50),
    phone VARCHAR(15)
);
