// src/server.ts

import express, { Request, Response } from 'express';
import bodyParser from 'body-parser';

const app = express();
const PORT = 3000;

app.use(bodyParser.json());

app.post('/transform', (req: Request, res: Response) => {
  const { inputJson, transformRules } = req.body;
  
  // Burada transform işlemini gerçekleştirin.
  // Örneğin, yalın bir JSON dönüşümü.
  try {
    let transformedJson = performTransformation(inputJson, transformRules);
    res.json({ result: transformedJson });
  } catch (error) {
    // Type assertion to ensure error is an instance of Error
    if (error instanceof Error) {
      res.status(500).json({ error: 'Transformation failed', details: error.message });
    } else {
      // Handle cases where error might not be an instance of Error
      res.status(500).json({ error: 'Transformation failed', details: String(error) });
    }
  }
});

app.listen(PORT, () => {
  console.log(`Server is running at http://localhost:${PORT}`);
});

function performTransformation(inputJson: any, transformRules: any) {
  // Basit bir Jolt transform benzeri işlem
  // Bu bölümü, uygun bir dönüşüm kütüphanesi ile değiştirin
  return inputJson; // Şimdilik dönüşüm yapılmıyor
}