-- Logical Replication Açma
ALTER SYSTEM SET wal_level = logical;
SELECT pg_reload_conf();

-- Debezium Kullanıcısına Yetki Verme
CREATE USER debezium WITH REPLICATION LOGIN PASSWORD 'debezium123';
GRANT CONNECT ON DATABASE sourcedb TO debezium;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO debezium;


-- Create Table
CREATE TABLE cari_kart (
    cari_id SERIAL PRIMARY KEY,         -- Cari Kart ID (Primary Key)
    ad VARCHAR(100),                    -- Cari Adı
    soyad VARCHAR(100),                 -- Cari Soyadı
    is_adres TEXT,                      -- İş Adresi
    ev_adres TEXT,                      -- Ev Adresi
    is_telefon VARCHAR(15),             -- İş Telefonu
    ev_telefon VARCHAR(15)              -- Ev Telefonu
);


-- Insert sample data
INSERT INTO cari_kart (ad, soyad, is_adres, ev_adres, is_telefon, ev_telefon) VALUES ('Ahmet', 'Yılmaz', 'İş Adresi 1, İstanbul', 'Ev Adresi 1, İstanbul', '212-1234567', '555-1234567');
INSERT INTO cari_kart (ad, soyad, is_adres, ev_adres, is_telefon, ev_telefon) VALUES ('Mehmet', 'Kaya', 'İş Adresi 2, Ankara', 'Ev Adresi 2, Ankara', '312-2345678', '532-2345678');
INSERT INTO cari_kart (ad, soyad, is_adres, ev_adres, is_telefon, ev_telefon) VALUES ('Ayşe', 'Demir', 'İş Adresi 3, İzmir', 'Ev Adresi 3, İzmir', '232-3456789', '533-3456789');
INSERT INTO cari_kart (ad, soyad, is_adres, ev_adres, is_telefon, ev_telefon) VALUES ('Fatma', 'Çelik', 'İş Adresi 4, Antalya', 'Ev Adresi 4, Antalya', '242-4567890', '534-4567890');
INSERT INTO cari_kart (ad, soyad, is_adres, ev_adres, is_telefon, ev_telefon) VALUES ('Ali', 'Öztürk', 'İş Adresi 5, Bursa', 'Ev Adresi 5, Bursa', '224-5678901', '535-5678901');
INSERT INTO cari_kart (ad, soyad, is_adres, ev_adres, is_telefon, ev_telefon) VALUES ('Zeynep', 'Şahin', 'İş Adresi 6, Konya', 'Ev Adresi 6, Konya', '332-6789012', '536-6789012');
INSERT INTO cari_kart (ad, soyad, is_adres, ev_adres, is_telefon, ev_telefon) VALUES ('Murat', 'Güven', 'İş Adresi 7, Eskişehir', 'Ev Adresi 7, Eskişehir', '222-7890123', '537-7890123');
INSERT INTO cari_kart (ad, soyad, is_adres, ev_adres, is_telefon, ev_telefon) VALUES ('Elif', 'Arslan', 'İş Adresi 8, Kayseri', 'Ev Adresi 8, Kayseri', '352-8901234', '538-8901234');
INSERT INTO cari_kart (ad, soyad, is_adres, ev_adres, is_telefon, ev_telefon) VALUES ('Ömer', 'Aydın', 'İş Adresi 9, Trabzon', 'Ev Adresi 9, Trabzon', '462-9012345', '539-9012345');
INSERT INTO cari_kart (ad, soyad, is_adres, ev_adres, is_telefon, ev_telefon) VALUES ('Gül', 'Uysal', 'İş Adresi 10, Samsun', 'Ev Adresi 10, Samsun', '362-0123456', '540-0123456');

INSERT INTO cari_kart (ad, soyad, is_adres, ev_adres, is_telefon, ev_telefon) VALUES ('Gül', 'Uysal', 'İş Adresi 10, Samsun', 'Ev Adresi 10, Samsun', '362-0123456', '540-0123456');
INSERT INTO cari_kart (ad, soyad, is_adres, ev_adres, is_telefon, ev_telefon) VALUES ('Ali', 'Kaya', 'İş Adresi 11, İstanbul', 'Ev Adresi 11, Ankara', '212-1234567', '555-1234567');
INSERT INTO cari_kart (ad, soyad, is_adres, ev_adres, is_telefon, ev_telefon) VALUES ('Ayşe', 'Demir', 'İş Adresi 12, İzmir', 'Ev Adresi 12, İzmir', '232-2345678', '533-2345678');
INSERT INTO cari_kart (ad, soyad, is_adres, ev_adres, is_telefon, ev_telefon) VALUES ('Mehmet', 'Yılmaz', 'İş Adresi 13, Bursa', 'Ev Adresi 13, Konya', '224-3456789', '532-3456789');
INSERT INTO cari_kart (ad, soyad, is_adres, ev_adres, is_telefon, ev_telefon) VALUES ('Elif', 'Polat', 'İş Adresi 14, Antalya', 'Ev Adresi 14, Antalya', '242-4567890', '534-4567890');
INSERT INTO cari_kart (ad, soyad, is_adres, ev_adres, is_telefon, ev_telefon) VALUES ('Can', 'Öztürk', 'İş Adresi 15, Trabzon', 'Ev Adresi 15, Trabzon', '462-5678901', '555-5678901');
INSERT INTO cari_kart (ad, soyad, is_adres, ev_adres, is_telefon, ev_telefon) VALUES ('Zeynep', 'Arslan', 'İş Adresi 16, Adana', 'Ev Adresi 16, Mersin', '322-6789012', '536-6789012');
INSERT INTO cari_kart (ad, soyad, is_adres, ev_adres, is_telefon, ev_telefon) VALUES ('Kerem', 'Çelik', 'İş Adresi 17, Kocaeli', 'Ev Adresi 17, Sakarya', '262-7890123', '537-7890123');
INSERT INTO cari_kart (ad, soyad, is_adres, ev_adres, is_telefon, ev_telefon) VALUES ('Oya', 'Karaca', 'İş Adresi 18, Kayseri', 'Ev Adresi 18, Kayseri', '352-8901234', '538-8901234');
INSERT INTO cari_kart (ad, soyad, is_adres, ev_adres, is_telefon, ev_telefon) VALUES ('Eren', 'Akman', 'İş Adresi 19, Gaziantep', 'Ev Adresi 19, Şanlıurfa', '342-9012345', '539-9012345');

-- View Data
SELECT * FROM public.cari_kart;

-- Clear table
DELETE FROM cari_kart 