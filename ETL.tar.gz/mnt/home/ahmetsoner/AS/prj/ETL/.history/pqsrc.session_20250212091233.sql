CREATE TABLE cari_kart (
    cari_id SERIAL PRIMARY KEY,         -- Cari Kart ID (Primary Key)
    ad VARCHAR(100),                    -- Cari Adı
    soyad VARCHAR(100),                 -- Cari Soyadı
    is_adres TEXT,                      -- İş Adresi
    ev_adres TEXT,                      -- Ev Adresi
    is_telefon VARCHAR(15),             -- İş Telefonu
    ev_telefon VARCHAR(15)              -- Ev Telefonu
);
