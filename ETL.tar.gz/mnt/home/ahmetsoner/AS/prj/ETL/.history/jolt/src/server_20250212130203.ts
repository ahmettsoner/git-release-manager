import express, { Request, Response } from 'express';
import bodyParser from 'body-parser';

const app = express();
const PORT = 3000;

app.use(bodyParser.json());
app.use(express.static('public'));  // Statik dosyalar için

app.post('/transform', (req: Request, res: Response) => {
  const { inputJson, transformRules } = req.body;

  try {
    let transformedJson = performTransformation(inputJson, transformRules);
    res.json({ result: transformedJson });
  } catch (error) {
    res.status(500).json({ error: 'Transformation failed', details: (error as Error).message });
  }
});

app.listen(PORT, () => {
  console.log(`Server is running at http://localhost:${PORT}`);
});

function performTransformation(inputJson: any, transformRules: any) {
  return inputJson; // Gelecekte değiştirilecek temel dönüşüm işlemi
}