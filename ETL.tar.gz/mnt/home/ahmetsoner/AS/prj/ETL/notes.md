## Initial Tasks
### Prepare Data Stores
* Run Docker Compose
```
docker-compose up -d
```

* Prepare pqsrc databse
```
psql -h localhost -p 5432 -U user -d pqsrc -f ./pqsrc.init.sql 
```

* Prepare pqdest databse
```
psql -h localhost -p 5433 -U user -d pqdest -f ./pqdest.init.sql
```

### Prepare CDC
* check kafka connect status
```
curl http://localhost:8083/ | jq .
```

* list kafka connect connectors
```
curl http://localhost:8083/connectors | jq .
```


* Delete connector if necessery
```bash
curl -X DELETE http://localhost:8083/connectors/<connector_name>
```

### Prepare Kafka

* List topics in kafka
```
sudo docker exec -it etl-kafka_1-1 kafka-topics --list --bootstrap-server localhost:9092
```


* View all messages in the topic
```
sudo docker exec -it etl-kafka_1-1 kafka-console-consumer --bootstrap-server localhost:9092 --from-beginning --topic <topic_name> | jq .
```

* Live View for latest messages in the topic
```
sudo docker exec -it etl-kafka_1-1 kafka-console-consumer --bootstrap-server localhost:9092 --topic <topic_name> | jq .
```


* Topic naming conventions
```
<source_db>.<target_db>.<process_stage>.<operation_type>.<table_name>
db1.db2.cdc.cari_kart
db2.db1.cdc.cari_kart
db1.db2.replica.cari_kart
db2.operation.cari_kart #insert, update, delete
```
---


## Full Nifi Sample
* for basic operations, completely on nifi dashboard

* Configure and run the PostgreSQL source connector
```
curl -i -X POST -H "Accept:application/json" -H "Content-Type:application/json" http://localhost:8083/connectors/ -d @debezium-postgres-connector-cari_kart.json
```

* check kafka connect connectors status
```
curl -X GET http://localhost:8083/connectors/pqsrc-connector/status | jq .
```

* goto [http://localhost:8080/nifi](http://localhost:8080/nifi)
  * login to nifi
    * username: `admin`
    * password: `adminadmin123`
  * add new processor choose `ConsumeKafka 2.2.0` 
    * Relationships: all terminate
    * Properties
      * Kafka Connection Service: 
        * Create (`Kafka3ConnectionService`)
          * Bootstrap Servers `kafka_1:9092,kafka_2:9092`
      * Group ID: `pqsrc_nifi`
      * Topics: `pqsrc.public.cari_kart`
  * start processor
  * add transform processor `JoltTransformJSON 2.2.0`
    * Relationships: all terminate
    * Properties
      * Use Jolt Spec: `cari_kart_inset.jolt.json`




### Nifi + JDBC Sink Connector Sample




* Configure and run the PostgreSQL source connector
```
curl -i -X POST -H "Accept:application/json" -H "Content-Type:application/json" http://localhost:8083/connectors/ -d @debezium-postgres-connector-customer_profile.json
```

* Configure and run the PostgreSQL JDBC Sink Connector
```
curl -i -X POST -H "Accept:application/json" -H "Content-Type: application/json" http://localhost:8084/connectors/ --data @jdbc-sink.json

```

* check kafka connect connectors status
```
curl -X GET http://localhost:8083/connectors/pqsrc-connector-customer_profile/status | jq .
```


### Full Spark Sample
* build docker image
```bash
sudo docker build -t my-spark-image:v1.3 .
```

* submit to spark
```bash
sudo docker exec etl-spark-master-1 /opt/spark/bin/spark-submit \
  --master spark://spark-master:7077 \
  --deploy-mode client \
  --packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.3.0 \
  --conf spark.sql.streaming.checkpointLocation=/tmp/checkpoint\
  /opt/spark-apps/cari_kart.py
```









```
wget https://repo1.maven.org/maven2/io/debezium/debezium-connector-postgres/3.0.7.Final/debezium-connector-postgres-3.0.7.Final-plugin.tar.gz
sudo tar -xzf debezium-connector-postgres-3.0.7.Final-plugin.tar.gz -C ./data/connect-jars
```

```
sudo wget https://packages.confluent.io/maven/io/confluent/kafka-connect-jdbc/10.8.0/kafka-connect-jdbc-10.8.0.jar -P data/connect-jars
```

