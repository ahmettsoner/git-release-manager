from datetime import datetime, timedelta
from airflow import DAG
from airflow.providers.apache.spark.operators.spark_submit import SparkSubmitOperator
from airflow.operators.python import PythonOperator

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2024, 2, 11),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5)
}

dag = DAG(
    'spark_kafka_job',
    default_args=default_args,
    description='Spark job to process Kafka data',
    schedule_interval=timedelta(minutes=5),
    catchup=False
)

# Spark job'unu çalıştır
spark_job = SparkSubmitOperator(
    task_id='spark_kafka_consumer',
    application="/opt/spark-apps/kafka_consumer.py",
    name="Kafka Consumer",
    conn_id="spark_default",
    conf={
        "spark.master": "spark://spark-master:7077",
        "spark.jars": "/opt/spark/jars/spark-sql-kafka-0-10_2.12-3.5.4.jar,"
                     "/opt/spark/jars/kafka-clients-3.5.1.jar,"
                     "/opt/spark/jars/commons-pool2-2.12.0.jar,"
                     "/opt/spark/jars/spark-token-provider-kafka-0-10_2.12-3.5.4.jar"
    },
    dag=dag
)
