from pyspark.sql import SparkSession
from pyspark.sql.functions import col, from_json, current_timestamp
from pyspark.sql.types import StructType, StructField, StringType

def process_kafka_data():
    # Spark Session'ı oluştur
    spark = SparkSession.builder \
        .appName("Kafka Consumer") \
        .master("spark://spark-master:7077") \
        .config("spark.jars", "/opt/spark/jars/spark-sql-kafka-0-10_2.12-3.5.4.jar," + 
                            "/opt/spark/jars/kafka-clients-3.5.1.jar," + 
                            "/opt/spark/jars/commons-pool2-2.12.0.jar," + 
                            "/opt/spark/jars/spark-token-provider-kafka-0-10_2.12-3.5.4.jar") \
        .getOrCreate()

    # Kafka'dan veri oku
    df = spark \
        .readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", "kafka_1:9092,kafka_2:9092") \
        .option("subscribe", "test-topic") \
        .option("startingOffsets", "earliest") \
        .load()



    # Veriyi işle
    processed_df = df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)") \
        .withColumn("processing_time", current_timestamp())

    # Sonuçları PostgreSQL'e yaz
    query = processed_df \
        .writeStream \
        .outputMode("append") \
        .format("console") \
        .option("truncate", False) \
        .start()

    query.awaitTermination()

if __name__ == "__main__":
    process_kafka_data()
