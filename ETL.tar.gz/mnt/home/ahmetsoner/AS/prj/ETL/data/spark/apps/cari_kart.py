from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col
from pyspark.sql.types import StructType, StringType

# Kafka'dan okuma için SparkSession oluştur
spark = SparkSession.builder \
    .appName("Kafka-Spark-Integration") \
    .master("spark://spark-master:7077") \
    .config("spark.jars.packages", "org.apache.spark:spark-sql-kafka-0-10_2.13:3.5.4") \
    .getOrCreate()

# Subscribe to 1 topic
df = spark \
  .readStream \
  .format("kafka") \
  .option("kafka.bootstrap.servers", "kafka_1:9092") \
  .option("subscribe", "pqsrc.public.cari_kart") \
  .load()

print("testttt")

schema = StructType() \
    .add("cari_id", StringType()) \
    .add("ad", StringType()) \
    .add("soyad", StringType())
value_df = df.selectExpr("CAST(value AS STRING)").select(from_json(col("value"), schema).alias("data")).select("data.*")
