from pyspark.sql import SparkSession
def main():
    # Initialize Spark session
    spark = SparkSession.builder \
        .appName("Hello World") \
        .master("spark://spark-master:7077") \
        .getOrCreate()

    # Create a simple DataFrame
    data = [("Hello",), ("World",)]
    df = spark.createDataFrame(data, ["message"])

    df = spark \
        .readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", "kafka_1:9092") \
        .option("subscribe", "pqsrc.public.cari_kart") \
        .load()

    # Show the DataFrame
    print("=== Hello World DataFrame ===")
    df.show()
    df.writeStream \
        .format("console") \
        .start() \
        .awaitTermination()

    # Stop the Spark session
    spark.stop()

if __name__ == "__main__":
    main()