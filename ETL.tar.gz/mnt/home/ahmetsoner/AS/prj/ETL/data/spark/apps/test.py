from pyspark.sql import SparkSession

# SparkSession başlat
spark = SparkSession.builder \
    .appName("HelloWorld") \
    .master("local[*]") \
    .getOrCreate()

# Basit bir veri kümesi (RDD) oluştur
data = ["Hello", "world!", "Welcome", "to", "Spark"]
rdd = spark.sparkContext.parallelize(data)

# Her kelimeyi yazdır
print("Contents of RDD:")
for word in rdd.collect():
    print(word)

# SparkSession sonlandır
spark.stop()