from pyspark.sql import SparkSession

def main():
    # Initialize Spark session
    spark = SparkSession.builder \
        .appName("Hello World") \
        .master("spark://spark-master:7077") \
        .getOrCreate()

    # Create a simple RDD
    rdd = spark.sparkContext.parallelize(["Hello", "World"])
    
    # Collect and print the results
    print("=== Hello World RDD ===")
    for word in rdd.collect():
        print(word)

    # Stop the Spark session
    spark.stop()

if __name__ == "__main__":
    main()
