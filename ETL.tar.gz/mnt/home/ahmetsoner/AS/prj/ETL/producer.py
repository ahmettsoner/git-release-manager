from kafka import KafkaProducer
import json
import time
from datetime import datetime

def json_serializer(data):
    return json.dumps(data).encode('utf-8')

# Kafka broker'ına bağlanma
producer = KafkaProducer(
    bootstrap_servers=['localhost:29092', 'localhost:29093'],
    value_serializer=json_serializer
)

def generate_message():
    return {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "message": f"Test message at {time.time()}",
        "value": round(time.time() % 100, 2)
    }

# Ana döngü
if __name__ == "__main__":
    print("Starting Kafka Producer...")
    topic_name = "test-topic"

    try:
        while True:
            message = generate_message()

            # Mesajı gönder
            producer.send(topic_name, message)
            print(f"Sent message: {message}")

            # Her saniye bir mesaj gönder
            time.sleep(1)

    except KeyboardInterrupt:
        print("\nStopping producer...")
        producer.close()
