from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col
from pyspark.sql.types import StructType, StringType

# Kafka'dan okuma için SparkSession oluştur
spark = SparkSession.builder \
    .appName("Kafka-Spark-Integration") \
    .master("spark://spark-master:7077") \
    .config("spark.jars.packages", "org.apache.spark:spark-sql-kafka-0-10_2.12:3.3.0") \
    .getOrCreate()

# Kafka veri şemasını tanımla
schema = StructType() \
    .add("cari_id", StringType()) \
    .add("ad", StringType()) \
    .add("soyad", StringType())

# Kafka'dan verileri okuma
kafka_df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "kafka_1:9092,kafka_2:9092") \
    .option("subscribe", "pqsrc.public.cari_kart") \
    .load()

print("Stream Readd:")

# Kafka verisini JSON'a çevir
value_df = kafka_df.selectExpr("CAST(value AS STRING)").select(from_json(col("value"), schema).alias("data")).select("data.*")

# İşlenen verileri konsola yaz (veya başka bir sink'e)
query = value_df.writeStream \
    .outputMode("append") \
    .format("console") \
    .start()

query.awaitTermination()