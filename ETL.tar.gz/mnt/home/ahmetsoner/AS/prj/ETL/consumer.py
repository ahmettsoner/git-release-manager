from kafka import KafkaConsumer
import json
import time
from kafka.errors import KafkaError
import logging

# Debug log'larını aktif et
# logging.basicConfig(level=logging.DEBUG)

def json_deserializer(data):
    try:
        return json.loads(data.decode('utf-8'))
    except:
        print(f"Deserialize hatası: {data}")
        return None

def create_consumer(retries=5, retry_delay=5):
    for attempt in range(retries):
        try:
            # Bağlantı parametrelerini güncelle
            consumer = KafkaConsumer(
                'test-topic',
                bootstrap_servers=['localhost:29092', 'localhost:29093'],
                auto_offset_reset='earliest',
                enable_auto_commit=True,
                group_id='my-group5',
                value_deserializer=json_deserializer,
                consumer_timeout_ms=1000,
                security_protocol='PLAINTEXT',
                request_timeout_ms=31000,
                session_timeout_ms=30000,
                max_poll_interval_ms=300000,
                connections_max_idle_ms=540000,
                reconnect_backoff_ms=50,
                reconnect_backoff_max_ms=1000
            )
            
            # Bağlantıyı test et
            topics = consumer.topics()
            print(f"Bağlantı başarılı. Mevcut topic'ler: {topics}")
            
            return consumer
            
        except KafkaError as e:
            if attempt == retries - 1:
                raise e
            print(f"Kafka'ya bağlanma hatası (Deneme {attempt + 1}/{retries}): {str(e)}")
            time.sleep(retry_delay)
        except Exception as e:
            if attempt == retries - 1:
                raise e
            print(f"Beklenmeyen hata (Deneme {attempt + 1}/{retries}): {str(e)}")
            time.sleep(retry_delay)

if __name__ == "__main__":
    print("Starting Kafka Consumer...")
    
    try:
        # Kafka'nın hazır olduğundan emin olmak için biraz bekle
        print("Kafka'nın hazır olması bekleniyor...")
        time.sleep(10)
        
        consumer = create_consumer()
        print("Kafka'ya başarıyla bağlandı. Mesajlar bekleniyor...")
        
        while True:
            try:
                message_batch = consumer.poll(timeout_ms=1000)
                
                if message_batch:
                    for tp, messages in message_batch.items():
                        for message in messages:
                            if message.value is not None:
                                print("------------------------")
                                print(f"Topic: {message.topic}")
                                print(f"Partition: {message.partition}")
                                print(f"Offset: {message.offset}")
                                print(f"Key: {message.key}")
                                print(f"Value: {message.value}")
                                print(f"Timestamp: {message.timestamp}")
                
            except Exception as e:
                print(f"Mesaj işleme hatası: {e}")
                continue
                
            time.sleep(0.1)
            
    except KafkaError as e:
        print(f"Kafka hatası: {e}")
    except Exception as e:
        print(f"Beklenmeyen hata: {e}")
        print(f"Hata detayı: {str(e)}")
        import traceback
        traceback.print_exc()
    except KeyboardInterrupt:
        print("\nStopping consumer...")
    finally:
        if 'consumer' in locals():
            consumer.close()